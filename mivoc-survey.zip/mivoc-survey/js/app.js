// Mivoc Survey - Shared App Logic (localStorage demo)

const Mivoc = {
  getUser() {
    const raw = localStorage.getItem('mivoc_user');
    return raw ? JSON.parse(raw) : null;
  },

  saveUser(user) {
    localStorage.setItem('mivoc_user', JSON.stringify(user));
  },

  logout() {
    localStorage.removeItem('mivoc_user');
    window.location.href = 'index.html';
  },

  requireAuth() {
    const user = this.getUser();
    if (!user) {
      window.location.href = 'login.html';
      return null;
    }
    return user;
  },

  updateBalance(amount) {
    const user = this.getUser();
    if (!user) return;
    user.balance = (user.balance || 0) + amount;
    user.totalEarned = (user.totalEarned || 0) + amount;
    this.saveUser(user);
    return user;
  },

  addHistory(entry) {
    const user = this.getUser();
    if (!user) return;
    user.history = user.history || [];
    user.history.unshift({
      ...entry,
      date: new Date().toISOString()
    });
    this.saveUser(user);
  },

  formatNaira(n) {
    return '₦' + Number(n).toLocaleString('en-NG');
  },

  showToast(msg, type = 'success') {
    let toast = document.querySelector('.toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.className = 'toast';
      document.body.appendChild(toast);
    }
    toast.textContent = msg;
    toast.className = 'toast show ' + type;
    setTimeout(() => toast.classList.remove('show'), 3000);
  },

  updateNav() {
    const user = this.getUser();
    const actions = document.querySelector('.nav-actions');
    if (!actions) return;

    if (user) {
      actions.innerHTML = `
        <a href="dashboard.html" class="btn btn-outline btn-sm">Dashboard</a>
        <a href="surveys.html" class="btn btn-primary btn-sm">Take Surveys</a>
      `;
    }
  }
};

// Init on every page
document.addEventListener('DOMContentLoaded', () => {
  Mivoc.updateNav();
});
